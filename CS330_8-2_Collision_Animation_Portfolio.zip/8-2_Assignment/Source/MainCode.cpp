#include <GLFW\glfw3.h>
#include "linmath.h"
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <iostream>
#include <vector>
#include <windows.h>
#include <time.h>

using namespace std;

const float DEG2RAD = 3.14159 / 180;

void processInput(GLFWwindow* window);

enum BRICKTYPE { REFLECTIVE, DESTRUCTABLE };
enum ONOFF { ON, OFF };

class Brick
{
public:
	float red, green, blue;
	float x, y, width;
	BRICKTYPE brick_type;
	ONOFF onoff;
	int hitsRemaining;

	Brick(BRICKTYPE bt, float xx, float yy, float ww, float rr, float gg, float bb)
	{
		brick_type = bt; x = xx; y = yy, width = ww; red = rr, green = gg, blue = bb;
		onoff = ON;
		hitsRemaining = 2;
	};

	void drawBrick()
	{
		if (onoff == ON)
		{
			double halfside = width / 2;

			glColor3d(red, green, blue);
			glBegin(GL_POLYGON);

			glVertex2d(x + halfside, y + halfside);
			glVertex2d(x + halfside, y - halfside);
			glVertex2d(x - halfside, y - halfside);
			glVertex2d(x - halfside, y + halfside);

			glEnd();
		}
	}
};


class Circle
{
public:
	float red, green, blue;
	float radius;
	float x;
	float y;
	float speed = 0.03;
	int direction; // 1=up 2=right 3=down 4=left 5 = up right   6 = up left  7 = down right  8= down left

	Circle(double xx, double yy, double rr, int dir, float rad, float r, float g, float b)
	{
		x = xx;
		y = yy;
		radius = rr;
		red = r;
		green = g;
		blue = b;
		radius = rad;
		direction = dir;
	}

	void CheckCollision(Brick* brk)
	{
		if (brk->brick_type == REFLECTIVE)
		{
			if ((x > brk->x - brk->width && x <= brk->x + brk->width) && (y > brk->y - brk->width && y <= brk->y + brk->width))
			{
				direction = GetRandomDirection();
				x = x + 0.03;
				y = y + 0.04;
			}
		}
		else if (brk->brick_type == DESTRUCTABLE)
		{
			if ((x > brk->x - brk->width && x <= brk->x + brk->width) && (y > brk->y - brk->width && y <= brk->y + brk->width))
			{
				if (brk->onoff == ON)
				{
					// Reduce the number of hits remaining.
					brk->hitsRemaining--;

					if (brk->hitsRemaining <= 0)
					{
						// Destroy the brick after two hits.
						brk->onoff = OFF;
					}
					else
					{
						// Make the brick darker after the first hit.
						brk->red *= 0.5f;
						brk->green *= 0.5f;
						brk->blue *= 0.5f;
					}
					// Change the circle`s direction after impact.
					direction = GetRandomDirection();
					// Move the circle outside the brick.
					x = brk->x + (x < brk->x ? -1.0f : 1.0f) * (brk->width + radius + 0.01f);
				}
			}
		}
	}

	int GetRandomDirection()
	{
		return (rand() % 8) + 1;
	}

	void MoveOneStep()
	{
		if (direction == 1 || direction == 5 || direction == 6)  // up
		{
			if (y > -1 + radius)
			{
				y -= speed;
			}
			else
			{
				// Bounce downward when the circle hits the top wall.
				if (direction == 1)
					direction = 3;
				else if (direction == 5)
					direction = 7;
				else if (direction == 6)
					direction = 8;
			}
		}

		if (direction == 2 || direction == 5 || direction == 7)  // right
		{
			if (x < 1 - radius)
			{
				x += speed;
			}
			else
			{
				// Bounce left when the circle hits the right wall.
				if (direction == 2)
					direction = 4;
				else if (direction == 5)
					direction = 6;
				else if (direction == 7)
					direction = 8;
			}
		}

		if (direction == 3 || direction == 7 || direction == 8)  // down
		{
			if (y < 1 - radius) {
				y += speed;
			}
			else
			{
				// Bounce upward when the circle hits the bottom wall.
				if (direction == 3)
					direction = 1;
				else if (direction == 7)
					direction = 5;
				else if (direction == 8)
					direction = 6;
			}
		}

		if (direction == 4 || direction == 6 || direction == 8)  // left
		{
			if (x > -1 + radius) {
				x -= speed;
			}
			else
			{
				// Bounce right when the circle hits the left wall.
				if (direction == 4)
					direction = 2;
				else if (direction == 6)
					direction = 5;
				else if (direction == 8)
					direction = 7;
			}
		}
	}

	void DrawCircle()
	{
		glColor3f(red, green, blue);
		glBegin(GL_POLYGON);
		for (int i = 0; i < 360; i++) {
			float degInRad = i * DEG2RAD;
			glVertex2f((cos(degInRad) * radius) + x, (sin(degInRad) * radius) + y);
		}
		glEnd();
	}
};


vector<Circle> world;


int main(void) {
	srand(time(NULL));

	if (!glfwInit()) {
		exit(EXIT_FAILURE);
	}
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
	GLFWwindow* window = glfwCreateWindow(480, 480, "8-2 Assignment", NULL, NULL);
	if (!window) {
		glfwTerminate();
		exit(EXIT_FAILURE);
	}
	glfwMakeContextCurrent(window);
	glfwSwapInterval(1);

	Brick brick(REFLECTIVE, 0.0, 0.58, 0.22, 1.0, 0.2, 0.6);
	Brick brick2(DESTRUCTABLE, -0.45, 0.15, 0.22, 0.2, 0.8, 1.0);
	Brick brick3(DESTRUCTABLE, 0.45, 0.15, 0.22, 0.9, 0.3, 1.0);
	Brick brick4(REFLECTIVE, 0.0, -0.28, 0.22, 1.0, 0.8, 0.2);

	while (!glfwWindowShouldClose(window)) {
		//Setup View
		float ratio;
		int width, height;
		glfwGetFramebufferSize(window, &width, &height);
		ratio = width / (float)height;
		glViewport(0, 0, width, height);
		glClear(GL_COLOR_BUFFER_BIT);

		processInput(window);

		//Movement
		for (int i = 0; i < world.size(); i++)
		{
			world[i].CheckCollision(&brick);
			world[i].CheckCollision(&brick2);
			world[i].CheckCollision(&brick3);
			world[i].CheckCollision(&brick4);
			world[i].MoveOneStep();
			world[i].DrawCircle();

		}
		for (int i = 0; i< world.size(); i++)
		{
			for (int j = i + 1; j< world.size(); j++)
			{
			float dx = world[i].x - world[j].x;
			float dy = world[i].y - world[j].y;
			float distance = sqrtf(dx * dx + dy * dy);
			float minDistance = world[i].radius + world[j].radius;

			if (distance < minDistance)
			{
				// Change the colors of both circles.
				world[i].red = (float)rand() / RAND_MAX;
				world[i].green = (float)rand() / RAND_MAX;
				world[i].blue = (float)rand() / RAND_MAX;
			
			    world[j].red = (float)rand() / RAND_MAX;
			    world[j].green = (float)rand() / RAND_MAX;
			    world[j].blue = (float)rand() / RAND_MAX;

			// Change direction after collision.
			world[i].direction = world[i].GetRandomDirection();
			world[j].direction = world[j].GetRandomDirection();

			// Separate overlapping circles.
			float nx = distance > 0.0001f ? dx / distance : 1.0f;
			float ny = distance > 0.0001f ? dy / distance : 0.0f;
			float push = (minDistance - distance + 0.02f) / 2.0f;

			world[i].x += nx * push;
			world[i].y += ny * push;
			world[j].x -= nx * push;
			world[j].y -= ny * push;
		}
	}
}

		brick.drawBrick();
		brick2.drawBrick();
		brick3.drawBrick();
		brick4.drawBrick();

		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	glfwDestroyWindow(window);
	glfwTerminate;
	exit(EXIT_SUCCESS);
}


void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS)
	{
		double r, g, b;
		r = rand() / 10000;
		g = rand() / 10000;
		b = rand() / 10000;
		Circle B(0, 0, 02, 5 +  rand() % 4, 0.05, r, g, b);
		world.push_back(B);
	}
}